const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');

const app = express();
app.use(bodyParser.json());

const TELEGRAM_TOKEN = 'YOUR_TELEGRAM_TOKEN';
const BYBIT_API_KEY = 'YOUR_BYBIT_API_KEY';
const BYBIT_API_SECRET = 'YOUR_BYBIT_API_SECRET';

app.post('/webhook', async (req, res) => {
    const message = req.body.message || req.body;
    console.log("Received message:", message);
    // Placeholder for order execution logic
    res.sendStatus(200);
});

app.get('/', (req, res) => {
    res.send('MrGiusBotPRO is running.');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});